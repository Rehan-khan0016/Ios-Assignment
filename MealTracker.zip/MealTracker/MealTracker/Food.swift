//
//  Food.swift
//  MealTracker
//
//  Created by Student on 18/08/25.
//

import Foundation

struct Food{
    var name: String
    var description: String
}
