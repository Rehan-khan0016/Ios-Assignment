//
//  Tab_Bar_ControllerTests.swift
//  Tab Bar ControllerTests
//
//  Created by Student on 30/07/25.
//

import Testing
@testable import Tab_Bar_Controller

struct Tab_Bar_ControllerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
