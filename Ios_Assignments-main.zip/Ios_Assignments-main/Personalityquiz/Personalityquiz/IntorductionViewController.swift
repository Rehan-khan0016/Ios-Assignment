//
//  ViewController.swift
//  Personalityquiz
//
//  Created by Jagpreet Singh on 1/08/25.
//

import UIKit

class IntorductionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue){
        
    }


}

