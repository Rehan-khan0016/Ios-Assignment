//
//  UIKitClassroomTests.swift
//  UIKitClassroomTests
//
//  Created by Krish Bahukhandi on 15/07/25.
//

import Testing
@testable import UIKitClassroom

struct UIKitClassroomTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
